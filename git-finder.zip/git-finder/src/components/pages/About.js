import React, { Fragment } from 'react'

const About = () => {
    return (
        <Fragment>
            <h1>About the GitHub Finder App</h1>
            <p>The purpose of this app is to allow users to search GitHub Users</p>
            <h6>Made by Hadi</h6>
        </Fragment>
    )
}

export default About